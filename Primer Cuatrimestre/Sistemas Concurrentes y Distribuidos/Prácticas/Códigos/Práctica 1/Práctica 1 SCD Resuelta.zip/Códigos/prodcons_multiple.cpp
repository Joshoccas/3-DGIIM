#include <iostream>
#include <cassert>
#include <thread>
#include <mutex>
#include <random>
#include "scd.h"
#include <atomic>

using namespace std ;
using namespace scd ;

//**********************************************************************
// Variables globales

const int num_hebras = 5;
const unsigned 
   num_items = 75 ,   // número de items
	tam_vec   = 15 ;   // tamaño del buffer
unsigned  
   cont_prod[num_items] = {0}, // contadores de verificación: para cada dato, número de veces que se ha producido.
   cont_cons[num_items] = {0}, // contadores de verificación: para cada dato, número de veces que se ha consumido.
   siguiente_dato       = 0 ;  // siguiente dato a producir en 'producir_dato' (solo se usa ahí)

atomic<int> primera_libre(0);
int productos[tam_vec] = {0};
Semaphore libres = tam_vec;
Semaphore ocupadas = 0;

//**********************************************************************
// funciones comunes a las dos soluciones (fifo y lifo)
//----------------------------------------------------------------------

unsigned producir_dato()
{
   this_thread::sleep_for( chrono::milliseconds( aleatorio<20,100>() ));
   const unsigned dato_producido = siguiente_dato ;
   siguiente_dato++ ;
   cont_prod[dato_producido] ++ ;
   cout << "producido: " << dato_producido << endl;
   return dato_producido ;
}
//----------------------------------------------------------------------

void consumir_dato( unsigned dato )
{
   assert( dato < num_items );
   cont_cons[dato] ++ ;
   this_thread::sleep_for( chrono::milliseconds( aleatorio<20,100>() ));

   cout << "                  consumido: " << dato << endl;

}


//----------------------------------------------------------------------

void test_contadores()
{
   bool ok = true ;
   cout << "comprobando contadores ...." ;
   for( unsigned i = 0 ; i < num_items ; i++ )
   {  if ( cont_prod[i] != 1 )
      {  cout << "error: valor " << i << " producido " << cont_prod[i] << " veces." << endl ;
         ok = false ;
      }
      if ( cont_cons[i] != 1 )
      {  cout << "error: valor " << i << " consumido " << cont_cons[i] << " veces" << endl ;
         ok = false ;
      }
   }
   if (ok)
      cout << endl << flush << "solución (aparentemente) correcta." << endl << flush ;
}

//----------------------------------------------------------------------

void  funcion_hebra_productora( int id )
{

   int inicio = id*(num_items/num_hebras);
   int fin = (id+1)*(num_items/num_hebras);
   for( unsigned i = inicio ; i < fin ; i++ )
   {
      int dato = producir_dato() ;
      sem_wait(libres);
      productos[primera_libre] = dato;
      primera_libre++;
      sem_signal(ocupadas);
   }
}

//----------------------------------------------------------------------

void funcion_hebra_consumidora( int id )
{

   int inicio = id*(num_items/num_hebras);
   int fin = (id+1)*(num_items/num_hebras);
   for( unsigned i = inicio ; i < fin ; i++ )
   {
      int dato ;
      sem_wait(ocupadas);
      dato = productos[primera_libre-1];
      primera_libre--;
      sem_signal(libres);
      consumir_dato( dato ) ;
    }
}
//----------------------------------------------------------------------

int main()
{
   cout << "-----------------------------------------------------------------" << endl
        << "Problema de los productores-consumidores (solución LIFO o FIFO ?)." << endl
        << "------------------------------------------------------------------" << endl
        << flush ;

   thread productores[num_hebras];
   thread consumidores[num_hebras];
   
   for(int i = 0; i < num_hebras; i++){
   
          productores[i] = thread (funcion_hebra_productora,i);
          consumidores[i] = thread (funcion_hebra_consumidora,i);
   }
   
   for(int i = 0; i < num_hebras; i++){
          productores[i].join();
   }
   
   for(int i = 0; i < num_hebras; i++){
          consumidores[i].join();
   }

    
   cout << "Fin de la ejecución de las hebras productoras y consumidoras" << endl;

   test_contadores();

   return 0;
}
